Put the four file insertionSort.cpp, mergeSort.cpp, heapSort.cpp, and quickSort.cpp into the same folder as parser.h and parser.cpp.
Only need to compile xxxSort.cpp. (ex: g++ insertionSort.cpp)

