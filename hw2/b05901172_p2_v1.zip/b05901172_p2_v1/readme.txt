Compiling: g++ maxPlanarSubset.cpp
Run: ./mps inputfile outputfile
Environment: linux (bash on window)