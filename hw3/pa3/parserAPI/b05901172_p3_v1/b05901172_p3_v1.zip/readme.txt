environment: linux (bash on window), gcc v7.3
compile: g++ -O3 main.cpp libparser.a -o parser
run: ./parser [inputfile] [outputfile]