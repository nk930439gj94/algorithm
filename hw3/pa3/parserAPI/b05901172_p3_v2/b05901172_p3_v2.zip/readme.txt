environment: linux (bash on window), gcc v7.3
compile: g++ -O3 router.cpp parser.cpp -o router
run: ./router [inputfile] [outputfile]