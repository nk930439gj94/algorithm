---------------------------------------------------
  AlgParser (Algorithms, Fall 2014 Program #3)
  Copyright (c) 2014
  Graduate Institute of Electronics Engineering
  Department of Electrical Engineering
  National Taiwan University

  Contact:
  Chau-Chin Huang <wlkb83@eda.ee.ntu.edu.tw>
----------------------------------------------------

Usage for the verification program:
   For Linux:
     ./verify_linux [test_case_file (*.in)] [your_output_file]

   For Windows:
     verify_win [test_case_file (*.in)] [your_output_file]

2. Example:

   For Linux:
     ./verify_linux ../benchmarks/gr5x5.in ../results/gr5x5.out

   For Windows (in cmd):
     verify_win.exe ../benchmarks/gr5x5.in ../results/gr5x5.out
